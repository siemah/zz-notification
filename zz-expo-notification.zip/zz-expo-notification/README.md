# Push Notification Expo

This Expo Plugin for WordPress is designed to simplify the integration of push notifications to all Android and iOS devices. With ease of use in mind.

## Instructions

You may use composer to make it easy and install the dependencies within the `/libs` folder as following:

```shell
composer install --ignore-platform-reqs
```

then zip your plugin and upload it to your woordpress instance.